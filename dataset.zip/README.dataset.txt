# hai > 2022-10-27 11:24pm
https://universe.roboflow.com/incognito-deciders/hai-gtivh

Provided by a Roboflow user
License: CC BY 4.0

bmw
